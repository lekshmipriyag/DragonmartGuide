<?php
/*
Plugin Name: WP Tab Widget
Plugin URI: http://mythemeshop.com/plugins/wp-tab-widget/
Description: WP Tab Widget is the AJAXified plugin which loads content by demand, and thus it makes the plugin incredibly lightweight.
Author: MyThemeShop
Version: 1.2.5
Author URI: http://mythemeshop.com/
*/
if ( !class_exists('wpt_widget') ) {
	class wpt_widget extends WP_Widget {
		function __construct() {
	        
	        // add image sizes and load language file
	        add_action( 'init', array(&$this, 'wpt_init') );
	        
			// ajax functions
			add_action('wp_ajax_wpt_widget_content', array(&$this, 'ajax_wpt_widget_content'));
			add_action('wp_ajax_nopriv_wpt_widget_content', array(&$this, 'ajax_wpt_widget_content'));
	        
	        // css
	        add_action('wp_enqueue_scripts', array(&$this, 'wpt_register_scripts'));	        

			$widget_ops = array('classname' => 'widget_wpt', 'description' => __('Display popular posts, recent posts, comments, and tags in tabbed format.', 'wp-tab-widget'));
			$control_ops = array('width' => 300, 'height' => 350);
			parent::__construct('wpt_widget', __('WP Tab Widget by MyThemeShop', 'wp-tab-widget'), $widget_ops, $control_ops);
	    }	
	    
	    function wpt_init() {
	        load_plugin_textdomain('wp-tab-widget', false, dirname(plugin_basename(__FILE__)) . '/languages/' );
	        
	    }
	    
	    function wpt_register_scripts() { 
			// JS    
			wp_register_script('wpt_widget', plugins_url('js/wp-tab-widget.js', __FILE__), array('jquery'));     
			wp_localize_script( 'wpt_widget', 'wpt',         
				array( 'ajax_url' => admin_url( 'admin-ajax.php' )) 
			);        
			// CSS     
			wp_register_style('wpt_widget', plugins_url('css/wp-tab-widget.css', __FILE__), true);
	    }  
	    	
		function form( $instance ) {
			$instance = wp_parse_args( (array) $instance, array( 
				'tabs' => array('recent' => 1, 'popular' => 1, 'comments' => 0, 'tags' => 0, 'product' => 0),
				'tab1content' => "asd",
				
			) );
			if  ( $instance ) {	
			}
			
			extract($instance);

			?>
	        <div class="wpt_options_form">

	        
	        <h4><?php _e('Select Tabs', 'wp-tab-widget'); ?></h4>
	        
			<div class="wpt_select_tabs">
				<p><h5>Tab 1</h5></p>
				<label class="alignleft" style="display: block; width: 50%; margin-bottom: 5px" for="<?php echo $this->get_field_id("tabs"); ?>_popular">
					<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("tabs"); ?>_popular" name="<?php echo $this->get_field_name("tabs"); ?>[popular]" value="1" <?php if (isset($tabs['popular'])) { checked( 1, $tabs['popular'], true ); } ?> />
					<?php _e( 'Enable Tab', 'wp-tab-widget'); ?>
				</label>
				<p>
				<label for="<?php echo $this->get_field_id('tab1title'); ?>">
					<?php _e('Title Tab 1:', 'wp-tab-widget'); ?>
					<br />
					<input type="text" id="<?php echo $this->get_field_id('tab1title'); ?>" name="<?php echo $this->get_field_name('tab1title'); ?>" value="<?php echo $tab1title; ?>" />
				</label>			
				</p>   
				<p>
				<label for="<?php echo $this->get_field_id('tab1content'); ?>">
					<?php _e('Title Tab 1:', 'wp-tab-widget'); ?>
					<br />
					<input type="text" id="<?php echo $this->get_field_id('tab1content'); ?>" name="<?php echo $this->get_field_name('tab1content'); ?>" value="<?php echo $tab1content; ?>" />

					
				</label>			
				</p> 
				<p><h5>Tab 2</h5></p>
				<label class="alignleft" style="display: block; width: 50%; margin-bottom: 5px;" for="<?php echo $this->get_field_id("tabs"); ?>_recent">
					<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("tabs"); ?>_recent" name="<?php echo $this->get_field_name("tabs"); ?>[recent]" value="1" <?php if (isset($tabs['recent'])) { checked( 1, $tabs['recent'], true ); } ?> />		
					<?php _e( 'Recent Tab', 'wp-tab-widget'); ?>
				</label>
				<label class="alignleft" style="display: block; width: 50%;" for="<?php echo $this->get_field_id("tabs"); ?>_comments">
					<input type="checkbox" class="checkbox wpt_enable_comments" id="<?php echo $this->get_field_id("tabs"); ?>_comments" name="<?php echo $this->get_field_name("tabs"); ?>[comments]" value="1" <?php if (isset($tabs['comments'])) { checked( 1, $tabs['comments'], true ); } ?> />
					<?php _e( 'Comments Tab', 'wp-tab-widget'); ?>
				</label>
				<label class="alignleft" style="display: block; width: 50%;" for="<?php echo $this->get_field_id("tabs"); ?>_tags">
					<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("tabs"); ?>_tags" name="<?php echo $this->get_field_name("tabs"); ?>[tags]" value="1" <?php if (isset($tabs['tags'])) { checked( 1, $tabs['tags'], true ); } ?> />
					<?php _e( 'Tags Tab', 'wp-tab-widget'); ?>
				</label>

				<label class="alignleft" style="display: block; width: 50%;" for="<?php echo $this->get_field_id("tabs"); ?>_product">
					<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("tabs"); ?>_product" name="<?php echo $this->get_field_name("tabs"); ?>[product]" value="1" <?php if (isset($tabs['product'])) { checked( 1, $tabs['product'], true ); } ?> />
					<?php _e( 'product Tab', 'wp-tab-widget'); ?>
				</label>
			</div>
	        
			</div><!-- .wpt_options_form -->
			<?php 
		}	
		
		function update( $new_instance, $old_instance ) {	
			$instance = $old_instance;    
			$instance['tabs'] = $new_instance['tabs'];	
			$instance['tab1title'] = $new_instance['tab1title'];	
					
			return $instance;	
		}	
		function widget( $args, $instance ) {	
			extract($args);     
			extract($instance);    
			wp_enqueue_script('wpt_widget'); 
			wp_enqueue_style('wpt_widget');  
			if (empty($tabs)) $tabs = array('recent' => 1, 'popular' => 1);    
			$tabs_count = count($tabs);     
			if ($tabs_count <= 1) {       
				$tabs_count = 1;       
			} elseif($tabs_count > 3) {   
				$tabs_count = 4;      
			}
			
	        
	        $available_tabs = array('popular' => __('Popular', 'wp-tab-widget'), 
	            'recent' => __('Recent', 'wp-tab-widget'), 
	            'comments' => __('Comments', 'wp-tab-widget'), 
	            'product' => __('Product', 'wp-tab-widget'), 
	            'tags' => __('Tags', 'wp-tab-widget'));
	        
			?>	
			<?php echo $before_widget; ?>	
			<div class="wpt_widget_content" id="<?php echo $widget_id; ?>_content" data-widget-number="<?php echo esc_attr( $this->number ); ?>">	
				<ul class="wpt-tabs <?php echo "has-$tabs_count-"; ?>tabs">
	                <?php foreach ($available_tabs as $tab => $label) { ?>
	                    <?php if (!empty($tabs[$tab])): ?>
	                        <li class="tab_title"><a href="#" id="<?php echo $tab; ?>-tab"><?php echo $label; ?></a></li>	
	                    <?php endif; ?>
	                <?php } ?> 
				</ul> <!--end .tabs-->	
				<div class="clear"></div>  
				<div class="inside">        
					<?php if (!empty($tabs['popular'])): ?>	
						<div id="popular-tab-content" class="tab-content">				
						</div> <!--end #popular-tab-content-->       
					<?php endif; ?>       
					<?php if (!empty($tabs['recent'])): ?>	
						<div id="recent-tab-content" class="tab-content"> 		 
						</div> <!--end #recent-tab-content-->		
					<?php endif; ?>                     
					<?php if (!empty($tabs['comments'])): ?>      
						<div id="comments-tab-content" class="tab-content"> 	
							<ul>                    		
							</ul>		
						</div> <!--end #comments-tab-content-->     
					<?php endif; ?>            
					<?php if (!empty($tabs['tags'])): ?>       
						<div id="tags-tab-content" class="tab-content"> 	
							<ul>                    	
							</ul>			 
						</div> <!--end #tags-tab-content-->  
					<?php endif; ?>

					<?php if (!empty($tabs['product'])): ?>       
						<div id="product-tab-content" class="tab-content"> 	
							<ul>                    	
							</ul>			 
						</div> <!--end #tags-tab-content-->  
					<?php endif; ?>
					<div class="clear"></div>
				</div> <!--end .inside -->
				
				<div class="clear"></div>
			</div><!--end #tabber -->
			
			<script type="text/javascript">  
				jQuery(function($) {    
					$('#<?php echo $widget_id; ?>_content').data('args', <?php echo json_encode($instance); ?>);  
				});  
			</script>  
			<?php echo $after_widget; ?>
			<?php 
		}  
		
		 
		function ajax_wpt_widget_content() {     
			$tab = $_POST['tab'];  
			
			$args = $_POST['args'];  
			
			//echo '<pre>';
			//var_dump($args["tab1content"]);
			//echo '</pre>';
	    	$number = intval( $_POST['widget_number'] );
			$page = intval($_POST['page']);    
			if ($page < 1)        
				$page = 1;

			if ( !is_array( $args ) || empty( $args ) ) { // json_encode() failed
				$wpt_widgets = new wpt_widget();
				$settings = $wpt_widgets->get_settings();

				if ( isset( $settings[ $number ] ) ) {
					$args = $settings[ $number ];
				} else {
					die( __('Unable to load tab content', 'wp-tab-widget') );
				}
			}

	        
			/* ---------- Tab Contents ---------- */    
			switch ($tab) {        
			  
				/* ---------- Popular Posts ---------- */   
				case "popular": 
					echo $args["tab1content"];
					?>       
					<p>Boutique festival Secret Garden went down in Sydney's Camden over the weekend, and all the free-spirited kids came out to...
	                </p>                   
					<?php           
				break;              
	            
				/* ---------- Recent Posts ---------- */      
				case "recent":           
					?>         
					<p>recent 1 </p>
					<?php       
				break;     
	            
				/* ---------- Latest Comments ---------- */        
				case "comments":         
					?>          
					<p>commets 1</p>
					<?php           
				break;             
	            
				/* ---------- Tags ---------- */   
				case "tags":        
					?>           
					<p>tags</p>           
					<?php            
				break;   
				case "product":           
					?>         
					<p>product 1 </p>
					<?php       
				break;           
			}              
			die(); // required to return a proper result  
		}  
	    
	    
	}
}
add_action( 'widgets_init', create_function( '', 'register_widget( "wpt_widget" );' ) );


?>